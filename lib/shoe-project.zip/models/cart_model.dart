import 'product_model.dart';

class CartItem {
  final Product product;
  int quantity;

  CartItem({
    required this.product,
    this.quantity = 1,
  });

  double get itemTotal {
    return product.price.toDouble() * quantity;
  }
}

// Cart Data Model only
class CartData {
  List<CartItem> items = [];
  double discountAmount = 0.0;
  String? appliedCoupon;
}
